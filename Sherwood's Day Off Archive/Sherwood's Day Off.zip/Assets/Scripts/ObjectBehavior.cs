﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectBehavior : MonoBehaviour {

    public int objectId;

    public List<int> miscInt;
    public List<float> miscFloat;
    public List<bool> miscBool;

    public List<GameObject> miscGameObject;

    GameObject player;

    /*OBJECT IDS
     * 0 - Empty
     * 1 - Collectable
     * 2 - Spring
     * 3 - One Way Platform
     * 4 - Heart
     * 5 - Bird
     */

	void Start () {
        player = GameObject.Find("Player");
        //Object Initiation
        switch (objectId)
        {
            case 1:
                int el = 0;
                foreach (GameObject c in GameObject.FindGameObjectsWithTag("collectable"))
                {
                    if (gameObject.name == "collectable (" + el.ToString() + ")")
                    {
                        miscInt[0] = el;
                    }
                    el++;
                }
                if (!LocalData.lD.collB[miscInt[0]])
                {
                    Destroy(gameObject);
                }
                break;
            case 2:
                miscGameObject[0] = transform.Find("hitCollider").gameObject;
                break;
            case 4:
                int hel = 0;
                foreach (GameObject h in GameObject.FindGameObjectsWithTag("heart"))
                {
                    if (gameObject.name == "heart (" + hel.ToString() + ")")
                    {
                        miscInt[0] = hel;
                    }
                    hel++;
                }
                if (!LocalData.lD.heartB[miscInt[0]])
                {
                    Destroy(gameObject);
                }

                miscFloat[2] = transform.position.y;

                break;
            case 5:
                int bel = 0;
                foreach (GameObject b in GameObject.FindGameObjectsWithTag("bird"))
                {
                    if (gameObject.name == "bird (" + bel.ToString() + ")")
                    {
                        miscInt[0] = bel;
                    }
                    bel++;
                }
                if (!LocalData.lD.birdB[miscInt[0]])
                {
                    Debug.Log("a");
                    LocalData.lD.bCounter++;
                    Destroy(gameObject);
                }
                break;
        }
	}

	void Update () {
		//Object Behavior
        switch (objectId)
        {
            case 1:
                //miscInt[0] = collectableId
                transform.eulerAngles = (new Vector3(transform.eulerAngles.x, transform.eulerAngles.y, transform.eulerAngles.z + (-100 * Time.deltaTime)));
                break;
            case 2:
                if (miscGameObject[0].GetComponent<playerFloorCollider>().check[0])
                {
                    player.GetComponent<PlayerMovement>().Jump(miscFloat[0], 10);
                }
                break;
            case 3:
                //miscBool[0] = playerAbove
                //miscFloat[0] = playerBoostHeight
                miscBool[0] = player.transform.position.y < transform.position.y;

                gameObject.GetComponent<BoxCollider2D>().isTrigger = miscBool[0];

                if (gameObject.GetComponent<playerFloorCollider>().check[0] && miscBool[0])
                {
                    player.GetComponent<PlayerMovement>().Jump(miscFloat[0], 0);
                }

                break;
            case 4:
                //miscInt[0] = heartId
                //miscFloat[0] = progress
                //miscFloat[1] = floatSpeed
                //miscFloat[2] = initialY
                transform.position = new Vector2(transform.position.x, miscFloat[2] + (0.5f * Mathf.Sin(miscFloat[0] * (Mathf.PI / 180))));
                miscFloat[0] += miscFloat[1] * Time.deltaTime;
                if (miscFloat[0] >= 360)
                {
                    miscFloat[0] = 360 - miscFloat[0];
                }
                break;
            case 5:
                //miscInt[0] = birdId
                if (GetComponent<playerFloorCollider>().check[0])
                {
                    Debug.Log("b");
                    LocalData.lD.bCounter++;
                    Destroy(gameObject);
                }
                break;
        }
	}
}
