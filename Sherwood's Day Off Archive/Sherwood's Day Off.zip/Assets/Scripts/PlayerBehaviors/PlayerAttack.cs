﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAttack : MonoBehaviour {

	void Start () {
		
	}
	
	void Update () {
		
	}

    public void SetPos(Vector2 newPos)
    {
        transform.position = newPos;
    }

}