﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBehavior : MonoBehaviour {

    //0 = empty
    public int enemyId;

    public List<int> miscInt;
    public List<float> miscFloat;
    public List<bool> miscBool;

    /*If the params are set respectively...
     * miscGameObject[0] = hitCollider
     * miscGameObject[1] = jumpCollider
     */
    public List<GameObject> miscGameObject;

    GameObject player;

    bool isAttackable;
    bool isJumpable;
    bool directDamage;

    /* ENEMY IDS:
     * 0 - Empty
     * 1 - Stationary Ground Wolf
     * 2 - Crawling Ground Wolf
     * 3 - Spike
     * 4 - Vertical Moving Owl
     * 5 - Horizontal Moving Owl
     * 6 - Circular Movement Owl
     * 7 - Bombing Owl
     * 8 - ^ Bomb
     * 9 - ^ Bomb Explosion
     * 10 - ^ Bomb Scheduler
     * */

	void Start () {
        player = GameObject.Find("Player");
		//Object Initiations
        switch (enemyId)
        {
            case 1:
                isAttackable = true;
                isJumpable = true;
                directDamage = true;
                break;
            case 2:
                isAttackable = true;
                isJumpable = true;
                directDamage = true;
                break;
            case 3:
                isAttackable = false;
                isJumpable = false;
                directDamage = true;
                break;
            case 4:
                isAttackable = true;
                isJumpable = true;
                directDamage = true;
                break;
            case 5:
                isAttackable = true;
                isJumpable = true;
                directDamage = true;
                break;
            case 6:
                isAttackable = true;
                isJumpable = true;
                directDamage = true;
                miscFloat[2] = transform.position.x;
                miscFloat[3] = transform.position.y;
                break;
            case 7:
                isAttackable = false;
                isJumpable = false;
                directDamage = true;
                if (miscInt[1] != 0)
                {
                    miscFloat[3] = -(0.99975576923f * (Mathf.Abs(miscFloat[1] - miscFloat[0])) * miscInt[1]) / (miscInt[2] * miscFloat[2]);
                } else
                {
                    miscFloat[3] = 0;
                }
                break;
            case 8:
                isAttackable = false;
                isJumpable = false;
                directDamage = false;
                break;
            case 9:
                isAttackable = false;
                isJumpable = false;
                directDamage = true;
                break;
        }
	}
	
	void Update () {
        //Object Behavior
        switch (enemyId)
        {
            case 1:
                break;
            case 2:
                float x1 = miscFloat[0];
                float x2 = miscFloat[1];
                float moveSpeed = miscFloat[2];

                float pos = transform.position.x;

                if (pos >= x2)
                {
                    miscInt[0] = -1;
                } else if (pos <= x1)
                {
                    miscInt[0] = 1;
                }

                int direction = miscInt[0];

                if (direction == 1)
                {
                    transform.position = new Vector2(pos + (moveSpeed * Time.deltaTime), transform.position.y);
                } else
                {
                    transform.position = new Vector2(pos - (moveSpeed * Time.deltaTime), transform.position.y);
                }
                break;
            case 4:
                float y1 = miscFloat[0];
                float y2 = miscFloat[1];
                float flySpeed = miscFloat[2];

                float posY = transform.position.y;

                if (posY >= y2)
                {
                    miscInt[0] = -1;
                }
                else if (posY <= y1)
                {
                    miscInt[0] = 1;
                }

                int dir = miscInt[0];

                if (dir == 1)
                {
                    transform.position = new Vector2(transform.position.x, posY + (flySpeed * Time.deltaTime));
                }
                else
                {
                    transform.position = new Vector2(transform.position.x, posY - (flySpeed * Time.deltaTime));
                }
                break;
            case 5:
                float X1 = miscFloat[0];
                float X2 = miscFloat[1];
                float flSpeed = miscFloat[2];

                float posX = transform.position.x;

                if (posX >= X2)
                {
                    miscInt[0] = -1;
                }
                else if (posX <= X1)
                {
                    miscInt[0] = 1;
                }

                int di = miscInt[0];

                if (di == 1)
                {
                    transform.position = new Vector2(posX + (flSpeed * Time.deltaTime), transform.position.y);
                }
                else
                {
                    transform.position = new Vector2(posX - (flSpeed * Time.deltaTime), transform.position.y);
                }
                break;
            case 6:
                //miscFloat[0] = rad
                //miscFloat[1] = speed
                //miscFloat[2] = originX
                //miscFloat[3] = originY
                //miscFloat[4] = circleProgress (set to 0)
                //miscInt[0] = directon (1 = clockwise, -1 = cclockwise)
                transform.position = new Vector2(miscFloat[2] + (miscFloat[0] * Mathf.Cos(miscFloat[4] * (Mathf.PI / 180))), miscFloat[3] + (miscFloat[0] * Mathf.Sin(miscFloat[4] * (Mathf.PI / 180))));
                miscFloat[4] = miscFloat[4] + ((miscFloat[1] * Time.deltaTime) * -miscInt[0]);
                if (Mathf.Abs(miscFloat[4]) >= 360)
                {
                    miscFloat[4] = 0 + ((Mathf.Abs(miscFloat[4]) - 360) * -miscInt[0]);
                }
                break;
            case 7:
                //miscFloat[0] = x1
                //miscFloat[1] = x2
                //miscFloat[2] = speed
                //miscFloat[3] = progress
                //miscFloat[4] = frequency (1 = right, -1 = left) << DELETE
                //miscFloat[5] = bombProgress
                //miscFloat[6] = bombFrequency
                //miscFloat[7] = bombRange
                //miscInt[0] = direction
                //miscInt[1] = schedulerId
                //miscInt[2] = maxScheduler
                //miscBool[0] = droppedBomb; Set to false
                //miscBool[1] = inProgress; Set to false
                //miscGameObject[2] = emptyParent

                if (miscFloat[3] >= 0)
                {
                    if (!miscBool[1])
                    {
                        transform.position = new Vector2(miscFloat[0], transform.position.y);
                    }
                    miscBool[1] = true;
                    transform.position = new Vector2(transform.position.x + (miscFloat[2] * Time.deltaTime * miscInt[0]), transform.position.y);
                    if (transform.position.x <= player.transform.position.x + miscFloat[7] && transform.position.x >= player.transform.position.x - miscFloat[7])
                    {
                        if (miscFloat[5] >= miscFloat[6])
                        {
                            miscBool[0] = true;
                            miscFloat[5] = 0;
                        }
                    }
                } else
                {
                    transform.position = new Vector2(-1000000 * miscInt[0], transform.position.y);
                }
                miscFloat[3] = miscFloat[3] + Time.deltaTime;
                miscFloat[5] = miscFloat[5] + Time.deltaTime;
                if ((miscInt[0] == 1 && transform.position.x >= miscFloat[1]) || (miscInt[0] == -1 && transform.position.x <= miscFloat[1]))
                {
                    miscBool[0] = false;
                    miscBool[1] = false;
                    miscFloat[3] = 0;
                }

                bool hit = miscGameObject[0].GetComponent<playerFloorCollider>().check[1];
                if (hit)
                {
                    if (miscBool[1])
                    {
                        miscFloat[3] = -0.99975576923f * (Mathf.Abs(miscFloat[1] - miscFloat[0])) / miscFloat[2] * (1 - ((Mathf.Abs(miscFloat[1] - miscFloat[0]) - Mathf.Abs(miscFloat[1] - transform.position.x)) / Mathf.Abs(miscFloat[1] - miscFloat[0])));
                    }
                    miscBool[0] = false;
                    miscBool[1] = false;
                }
                if (isJumpable)
                {
                    bool jumpedOn = miscGameObject[1].GetComponent<playerFloorCollider>().check[0];
                    if (jumpedOn)
                    {
                        player.GetComponent<PlayerMovement>().Jump(1.5f, 0);
                        miscBool[0] = false;
                        miscBool[1] = false;
                        miscFloat[3] = -0.99975576923f * (Mathf.Abs(miscFloat[1] - miscFloat[0])) / miscFloat[2] * ((Mathf.Abs(miscFloat[1] - miscFloat[0]) - Mathf.Abs(miscFloat[1] - transform.position.x)) / Mathf.Abs(miscFloat[1] - miscFloat[0]));
                    }
                }
                break;
            case 8:
                
                break;
            case 9:
                //miscGameObject[0] = self
                //miscGameObject[1] = pairedBomb
                //miscFloat[0] = limit
                //miscFloat[1] = limit
                //miscBool[0] = bombExploded
                //miscBool[1] = cannotExplode
                miscBool[0] = miscGameObject[1].GetComponent<EnemyBehavior>().miscBool[2];
                if (miscBool[0] && !miscBool[1])
                {
                    miscBool[1] = true;
                    transform.position = new Vector2(miscGameObject[1].transform.position.x, miscGameObject[1].transform.position.y + 1);
                    miscFloat[0] = 0;
                } else if (!miscBool[0])
                {
                    miscBool[1] = false;
                }
                if (miscFloat[0] >= miscFloat[1])
                {
                    transform.position = new Vector2(1000000000, 1000000000);
                }
                miscFloat[0] = miscFloat[0] + Time.deltaTime;
                break;
        }

        if (isAttackable)
        {
            bool hit = miscGameObject[0].GetComponent<playerFloorCollider>().check[1];
            if (hit)
            {
                Destroy(gameObject);
            }
        }
        if (isJumpable)
        {
            bool jumpedOn = miscGameObject[1].GetComponent<playerFloorCollider>().check[0];
            if (jumpedOn)
            {
                player.GetComponent<PlayerMovement>().Jump(1.5f, 0);
                Destroy(gameObject);
            }
        }
        if (directDamage)
        {
            if (miscGameObject[0].GetComponent<playerFloorCollider>().check[0])
            {
                player.GetComponent<PlayerMovement>().Hurt(1);
            }
        }
	}
    void FixedUpdate()
    {
        switch (enemyId)
        {
            case 8:
                //miscGameObject[0] = parentOwl (leave empty)
                //miscBool[0] = active
                //miscBool[1] = activeBuffer
                //miscBool[2] = exploded

                Rigidbody2D rb0 = gameObject.GetComponent<Rigidbody2D>();

                miscGameObject[0] = transform.parent.gameObject;
                if (!miscGameObject[0].GetComponent<EnemyBehavior>().miscBool[0])
                {
                    miscBool[2] = false;
                }
                if (!miscBool[2])
                {
                    miscBool[0] = miscGameObject[0].GetComponent<EnemyBehavior>().miscBool[0];
                }
                else
                {
                    miscBool[0] = false;
                }
                gameObject.GetComponent<Rigidbody2D>().isKinematic = !miscBool[0];
                if (!miscBool[1] && miscBool[0])
                {
                    miscBool[2] = false;
                    transform.position = new Vector2(miscGameObject[0].transform.position.x, miscGameObject[0].transform.position.y - 2);
                    miscBool[1] = true;
                }
                else if (!miscBool[0])
                {
                    miscBool[1] = false;
                    transform.position = new Vector2(-1000000, -1000000);
                    gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(0, 0);
                }
                playerFloorCollider a = gameObject.GetComponent<playerFloorCollider>();
                if (a.check[0] || a.check[1] || a.check[2])
                {
                    miscBool[2] = true;
                    miscGameObject[0].GetComponent<EnemyBehavior>().miscBool[0] = false;
                }

                if (rb0.velocity.y <= -40)
                {
                    rb0.velocity = new Vector2(rb0.velocity.x, -40);
                }

                break;
        }
    }
}