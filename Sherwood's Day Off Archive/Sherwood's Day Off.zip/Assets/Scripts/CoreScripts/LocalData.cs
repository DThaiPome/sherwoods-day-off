﻿using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;
using UnityEngine.UI;

public class LocalData : MonoBehaviour {

    //Collectables
    public List<bool> collB;
    public int cCounter = 0;
    public GameObject cCounterText;

    //Health
    public List<bool> heartB;
    public int hCounter = 2;
    public GameObject hCounterText;

    //Bird
    public List<bool> birdB;
    public int bCounter = 0;
    public GameObject bCounterText;

    public static LocalData lD;

    public static bool loaded = false;

    void Awake ()
    {

        if (lD == null)
        {
            DontDestroyOnLoad(gameObject);
            lD = this;
        }
        else if (lD != this)
        {
            Destroy(gameObject);
        }

        if (!loaded)
        {
            foreach (GameObject c in GameObject.FindGameObjectsWithTag("collectable"))
            {
                collB.Add(true);
            }
            foreach (GameObject h in GameObject.FindGameObjectsWithTag("heart"))
            {
                heartB.Add(true);
            }
            foreach (GameObject b in GameObject.FindGameObjectsWithTag("bird"))
            {
                birdB.Add(true);
            }
        }
    }

    void Update () {
        cCounterText = GameObject.Find("Collectable Counter");
        cCounterText.GetComponent<Text>().text = cCounter.ToString();

        hCounterText = GameObject.Find("Health Counter");
        hCounterText.GetComponent<Text>().text = hCounter.ToString();

        bCounterText = GameObject.Find("Bird Counter");
        bCounterText.GetComponent<Text>().text = bCounter.ToString() + "/" + birdB.Count.ToString();
    }

    public void ScanForCollectables()
    {
        for (int i = 0; i < collB.Count; i++)
        {
            if (GameObject.Find("collectable (" + i.ToString() + ")") == null)
            {
                collB[i] = false;
            }
        }
        for (int i = 0; i < heartB.Count; i++)
        {
            if (GameObject.Find("heart (" + i.ToString() + ")") == null)
            {
                heartB[i] = false;
            }
        }
        for (int i = 0; i < birdB.Count; i++)
        {
            if (GameObject.Find("bird (" + i.ToString() + ")") == null)
            {
                birdB[i] = false;
            }
        }
    }

}
