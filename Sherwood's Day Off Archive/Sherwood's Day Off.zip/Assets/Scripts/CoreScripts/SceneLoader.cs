﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneLoader : MonoBehaviour {

    static Vector2 loadPos = new Vector2(0, 1);

    public Vector2 shPos;

	void Awake () {
        shPos = loadPos;
    }

	void Update () {
        shPos = loadPos;
	}

    public void SetPos(Vector2 newPos)
    {
        loadPos = newPos;
    }

    public void LoadWPos(int sI)
    {
        SceneManager.LoadScene(sI);
    }

}
